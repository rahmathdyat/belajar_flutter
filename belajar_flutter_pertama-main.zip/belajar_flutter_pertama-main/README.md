# belajar_flutter_pertama
## Profil
| Variable | Isi |
| -------- | --- |
| **Nama** | Satria Dwi Aprianto |
| **NIM** | 312210490 |
| **Kelas** | TI.22.A5 |
| **Mata Kuliah** | Pemrograman Mobile |


https://github.com/SatriaDwiA/belajar_flutter_pertama/assets/130272478/6081595b-d264-430f-bb77-29df3a01cafb

